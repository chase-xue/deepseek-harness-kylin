DeepSeek Harness resources directory.
On deployment, system electron will launch app.asar placed here.
